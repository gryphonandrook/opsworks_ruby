# CHANGELOG for whenever

This file is used to list changes made in each version of whenever.

## 0.1.0:

* Initial release of whenever
