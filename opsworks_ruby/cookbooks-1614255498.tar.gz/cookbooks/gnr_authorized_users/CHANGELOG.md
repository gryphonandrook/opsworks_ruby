# CHANGELOG for gnr_authorized_users

This file is used to list changes made in each version of gnr_authorized_users.

## 0.1.0:

* Initial release of gnr_authorized_users
