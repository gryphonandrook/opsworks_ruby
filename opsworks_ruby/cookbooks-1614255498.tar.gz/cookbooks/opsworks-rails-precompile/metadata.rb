name             'opsworks-rails-precompile'
maintainer       'Stefan Wrobel'
maintainer_email ''
license          'All rights reserved'
description      'Installs/Configures opsworks-rails-precompile'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '1.0.0'

