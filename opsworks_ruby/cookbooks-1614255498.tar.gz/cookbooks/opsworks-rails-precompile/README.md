# Recipes

`opsworks-rails-precompile::default`
`opsworks-rails-precompile::symlink`

# Author

Stefan Wrobel

# License

MIT (fork & let fork)
