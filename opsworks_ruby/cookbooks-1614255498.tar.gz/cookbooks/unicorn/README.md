unicorn template Cookbook
====================
