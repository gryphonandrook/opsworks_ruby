nginx template Cookbook
====================
