ElasticSearch Cookbook
====================
Configures elasticsearch.

Requirements
------------

Usage
-----
#### elasticsearch::nginx_upstream

