# CHANGELOG for elasticsearch

This file is used to list changes made in each version of elasticsearch.

## 0.1.0:

* Initial release of elasticsearch
