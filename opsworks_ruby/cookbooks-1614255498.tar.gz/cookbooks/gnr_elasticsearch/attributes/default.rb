default[:elasticsearch][:version]               = '1.4.5'
default[:elasticsearch][:server_port_upstream]  = '9200'
default[:elasticsearch][:server_port_listen]    = '9200'
