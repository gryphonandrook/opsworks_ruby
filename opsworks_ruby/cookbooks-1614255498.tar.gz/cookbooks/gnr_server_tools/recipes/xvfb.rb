package 'xvfb' do
  action :install
end
