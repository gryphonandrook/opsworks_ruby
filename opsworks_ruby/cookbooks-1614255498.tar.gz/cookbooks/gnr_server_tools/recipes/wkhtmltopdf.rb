package 'wkhtmltopdf' do
  action :install
end
