# CHANGELOG for gnr_install_wkhtmltopdf

This file is used to list changes made in each version of gnr_server_tools.

## 0.1.1:

* Updated to handle multiple server tools 

## 0.1.0:

* Initial release of gnr_install_wkhtmltopdf
