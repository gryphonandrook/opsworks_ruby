name              'gnr_server_tools'
maintainer        'Gryphon & Rook Inc'
license           'All rights reserved'
description       'Install Customized Server Tools'
long_description  IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version           '0.1.1'
