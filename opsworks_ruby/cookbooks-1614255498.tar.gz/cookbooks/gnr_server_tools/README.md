gnr_server_tools Cookbook
====================
Installs custom tools for the server
